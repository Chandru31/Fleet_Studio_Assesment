package com.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base.BaseClass;

public class LoginPage extends BaseClass{
	
	public LoginPage() {
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "input-email")
	private WebElement txtUsername;
	
	@FindBy(id = "input-password")
	private WebElement txtUserPass;
	
	@FindBy(xpath = "//input[@type='submit']")
	private WebElement btnLogin;
	
	@FindBy(xpath = "//div[@class='form-group']//descendant::a[text()='Forgotten Password']")
	private WebElement btnForgetPass;

	public WebElement getTxtUsername() {
		return txtUsername;
	}

	public void setTxtUsername(WebElement txtUsername) {
		this.txtUsername = txtUsername;
	}

	public WebElement getTxtUserPass() {
		return txtUserPass;
	}

	public void setTxtUserPass(WebElement txtUserPass) {
		this.txtUserPass = txtUserPass;
	}

	public WebElement getBtnLogin() {
		return btnLogin;
	}

	public void setBtnLogin(WebElement btnLogin) {
		this.btnLogin = btnLogin;
	}

	public WebElement getBtnForgetPass() {
		return btnForgetPass;
	}

	public void setBtnForgetPass(WebElement btnForgetPass) {
		this.btnForgetPass = btnForgetPass;
	}



}
