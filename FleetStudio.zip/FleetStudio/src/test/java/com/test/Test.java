package com.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.base.BaseClass;
import com.pages.LoginPage;

public class Test extends BaseClass {



	@org.testng.annotations.Test
	public void testFirstNameField() throws InterruptedException {

		launchBrowser();
		launchUrl("https://tutorialsninja.com/demo/index.php?route=account/login");

		LoginPage l = new LoginPage();
		
		
		//1-user enter user name and click on login button and verify the error message
		enterText(l.getTxtUsername(), "Admin");

		Thread.sleep(3000);
		
		
		click(l.getBtnLogin());

		WebElement errorMessage = driver.findElement(By.xpath("//div[@class='alert alert-danger alert-dismissible']"));

		Assert.assertEquals(errorMessage.getText(), "Warning: No match for E-Mail Address and/or Password.");

		l.getTxtUsername().clear();

		Thread.sleep(3000);
		
		//2-user enter user name, password and refresh the page

		enterText(l.getTxtUsername(), "Admin");

		enterText(l.getTxtUserPass(), "admin123");

		Thread.sleep(3000);

		driver.navigate().refresh();
		
		//3-user enter user name, password and click on login button

		l.getTxtUsername().clear();

		enterText(l.getTxtUsername(), "Admin");

		enterText(l.getTxtUserPass(), "admin123");

		Thread.sleep(3000);

		click(l.getBtnLogin());
		
		Thread.sleep(3000);
		
		//4-user enter special characters in user name, password and click on login button

		l.getTxtUsername().clear();
		
		l.getTxtUserPass().clear();
		
		enterText(l.getTxtUsername(), "$%^&*(");

		enterText(l.getTxtUserPass(), "(*&^%$#");

		Thread.sleep(3000);

		click(l.getBtnLogin());
		
		//5-user enter user name, password and click on forget password button

		l.getTxtUsername().clear();
		
		l.getTxtUserPass().clear();
		
		enterText(l.getTxtUsername(), "Admin");

		enterText(l.getTxtUserPass(), "admin123");

		Thread.sleep(3000);
		
		click(l.getBtnForgetPass());
		


	}


}
